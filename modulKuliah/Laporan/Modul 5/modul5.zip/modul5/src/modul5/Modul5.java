/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul5;
import java.util.Scanner;
public class Modul5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

          int a=5;

          int b;       

          switch(a) {

              case 1: b = a + 1;

              case 2: b = a + 2;

              case 3: b = a + 3;

              case 4: b = a + 4;

              case 5: b = a + 5;

              break;

              default: b = 0;

      }                  

      System.out.println("Nilai b: " + b);       

     }}




